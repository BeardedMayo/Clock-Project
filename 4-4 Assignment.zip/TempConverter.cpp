#include<iostream>
#include<string>
#include<fstream>
#include<cmath>
using namespace std;

int main() {
    
    string cityName;                            //variables for city name and temperature
    int fahrenheit, celcius;

    ifstream inFile;                            //Creating file object to read from a file
    
    inFile.open("FahrenheitTemperature.txt");   //Opening the file "FahrenheitTemperature.txt' using the input file object

    ofstream outFile;                           //Creating file object to write to a file
    
    outFile.open("CelsiusTemperature.txt");     //Opening the file "CelsiusTemperature.txt' using the output file object

    if (!inFile) {                                   //Checks if input file cannot be opened
        cout << "File cannot be opened." << endl;
    }
    else {                                           //Loops till end of the file
       
        while (inFile >> cityName >> fahrenheit) {   //Reads city name and fahrenheit in each line of file
            
            celcius = (int)round(((fahrenheit - 32) * 5) / (double)9);      //Converts fahrenheit temperature to celcius temperature
            
            outFile << cityName << " " << celcius << endl;                  //Writes the city name and celcius value to 'CelsiusTemperature.txt' file
        }
    }

    inFile.close();                             //Close both file objects
    outFile.close();

    return 0;
}